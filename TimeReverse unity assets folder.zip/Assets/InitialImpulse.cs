﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InitialImpulse : MonoBehaviour {

	public float impulseMagnitude = 10f;

	// Use this for initialization
	void Start () {


	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetKeyDown (KeyCode.Space)) {
			GetComponent<Rigidbody> ().AddForce (Vector3.left * impulseMagnitude, ForceMode.Impulse);

		}
		
	}
}
