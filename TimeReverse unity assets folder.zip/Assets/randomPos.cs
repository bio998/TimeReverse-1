﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class randomPos : MonoBehaviour {

	public Transform[] cubes0;
	public Transform[] cubes;

	public float timeScale = 1f;
	float timeScale0 = 1f;

	void Start () {

		timeScale0 = timeScale;

		cubes0 = GetComponentsInChildren<Transform> ();
		cubes = new Transform[cubes0.Length - 1];

		for (int i = 1; i < cubes0.Length; i++) {//for some reason getcomponents in children also stupidly gets the component in the parent so here i chop it off by cutting array element 0 from the transform array
			cubes [i-1] = cubes0 [i];
		}

		for (int i = 0; i < cubes.Length; i++) {
			//cubes [i].position = new Vector3 ((float)(i % 4) / 2f, Random.Range (-0.5f, 0.5f) + 2f, (float)(i / 4) / 2f); 
			//cubes [i].position = new Vector3 ((float)i/2f, 2f, 0f); 
				//new Vector3 (Random.Range (-2f, 2f), Random.Range (-0.5f, 0.5f) + 2f, Random.Range (-2f, 2f));
			Rigidbody rig = cubes [i].GetComponent<Rigidbody> ();

			cubes[i].rotation = Quaternion.Euler(new Vector3(Random.Range (0f, 360f),Random.Range (0f, 360f),Random.Range (0f, 360f)));
			rig.velocity = Vector3.zero;
		}
		
	}
	
	void Update () {

		if(Input.GetKeyDown (KeyCode.Alpha1)){
			timeScale = 1f;
		}

		if(Input.GetKeyDown (KeyCode.Alpha2)){
			timeScale = 0.5f;
		}

		if(Input.GetKeyDown (KeyCode.Alpha3)){
			timeScale = -0.5f;
		}

		if(Input.GetKeyDown (KeyCode.Alpha4)){
			timeScale = -1f;
		}

		for (int i = 0; i < cubes.Length; i++) {

			Rigidbody rig = cubes [i].GetComponent<Rigidbody> ();

			//velocity is effectively scaled by the time scale factor
			Vector3 v0 = rig.velocity;

			if (timeScale0 != timeScale) {

				rig.velocity = v0 * timeScale / timeScale0;



			}

			//acceleration due to gravity is effectively scaled by time squared cf m/s^2
			float scaledGravityAcc = -9.81f * timeScale * timeScale;

			rig.AddForce(new Vector3 (0, scaledGravityAcc, 0)); // adds the force of gravity augmented by the time scale factor





			
		}

		timeScale0 = timeScale;
		
	}
}
