﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class reactionForce : MonoBehaviour {

	bool timeReverse = false;

	randomPos ranpos;


	void Start () {

		ranpos = GetComponentInParent<randomPos> ();
		
	}

	//public float kickStrength = 1.0f;

	void OnCollisionEnter(Collision collision) {

		//timeReverse = ranpos.timeScale < 0;


		float bounciness = GetComponent<Collider> ().material.bounciness;

		float reverseBounciness = 1f + (1f - bounciness);

		ContactPoint contact = collision.contacts[0];

		Rigidbody otherRigidbody = collision.rigidbody;


		if (timeReverse) {
			//otherRigidbody.AddForceAtPosition (- collision.impulse, contact.point, ForceMode.Impulse);
		}


	}



	// Update is called once per frame
	void Update () {
		
	}
}

/*
impulse0 = 1;

impulse = (1 + bounciness )/2;
impulse_ = (1 + bounciness_ )/2;
bounciness_ = 2 - bounciness;

impulse_ = (1 + 2 - bounciness)/2;
= -( -4 + 1 + bounciness)/2
	= 2 - impulse;

2 = (1 + bounciness)/impulse

	impulse_ = 

*/